package com.cg.Banking.beans;

public class Transaction {
		private int transactionId, amount;
		private String  timeStamp,transactionType;
		public Transaction(int transactionId, int amount, String timeStamp, String transactionType) {
			super();
			this.transactionId = transactionId;
			this.amount = amount;
			this.timeStamp = timeStamp;
			this.transactionType = transactionType;
		}
		public int getTransactionId() {
			return transactionId;
		}
		public void setTransactionId(int transactionId) {
			this.transactionId = transactionId;
		}
		public int getAmount() {
			return amount;
		}
		public void setAmount(int amount) {
			this.amount = amount;
		}
		public String getTimeStamp() {
			return timeStamp;
		}
		public void setTimeStamp(String timeStamp) {
			this.timeStamp = timeStamp;
		}
		public String getTransactionType() {
			return transactionType;
		}
		public void setTransactionType(String transactionType) {
			this.transactionType = transactionType;
		}
		

}
