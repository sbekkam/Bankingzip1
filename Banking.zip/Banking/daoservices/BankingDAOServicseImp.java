package com.cg.Banking.daoservices;

public class BankingDAOServicseImp {

}
