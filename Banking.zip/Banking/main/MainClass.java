package com.cg.Banking.main;


import com.cg.Banking.beans.Account;
import com.cg.Banking.beans.Address;
import com.cg.Banking.beans.Customer;


public class MainClass {

	public static void main(String[] args) {
		String nameToBeSearch= "sushma";
		Customer customer = searchname(nameToBeSearch);
		if(customer!=null)
			System.out.println(customer.getCustomerId()+" "+ customer.getMobileNo()); 		
		else
			System.out.println("customer deals with ID "+ nameToBeSearch + " not found");
	}
	public static Customer searchname(String firstName){
		Customer []customers = new Customer[2];
		 customers[0] = new Customer(1234, 849987291, 12345678, "sushma", "bekkam", "12345678", "abcd@gmail.com", "07-04-1996",new Address("manuguru", "telangan", "india", 507117), new Account(accountNo, accountBalance, accountType))
		 //associates[1] = new Associate(1236, 15000, "veena", "yeshala", "mainframe", "software", "efgh5678", "efgh@gmail.com");
		 for(Customer customer:customers){
			 if(customer!=null &&customer.getFirstName()=="sushma")
				 return customer;
			 
			}
		 return null;

}
}
